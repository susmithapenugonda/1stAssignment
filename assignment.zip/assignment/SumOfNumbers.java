package assignment;

public class SumOfNumbers {

	public static void main(String[] args) {
		
		int a= 10;
		float f = 90.78f;
		int b = 111;
		int c = 8989;
		int d = 7876;
		float sum;
		
		sum = a+f+b+c+d;
		
		System.out.println(sum);

	}

}
