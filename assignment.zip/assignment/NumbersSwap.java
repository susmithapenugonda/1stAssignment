package assignment;

public class NumbersSwap {

	public static void main(String[] args) {

   int a=10;
   int b=20;
   System.out.println("Before Swap Numbers are");
   System.out.println("a = " + a);
   System.out.println("b = " + b);
   
   //swapping
   a = b-a;
   b= a;
   a=a+b;
 System.out.println("After Swap Numbers are");
 System.out.println("a = " + a);
 System.out.println("b = " + b);
	}

}
