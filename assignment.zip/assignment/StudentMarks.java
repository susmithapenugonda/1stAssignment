package assignment;

public class StudentMarks {

	public static void main(String[] args) {
		
		int []arr = {78,12,89,55,35};
		
		for(int i=0;i<arr.length;i++)
		
		{
			if(arr[i]>80)
			{
			System.out.println(arr[i]);
			
			}
		}
	}

	}


