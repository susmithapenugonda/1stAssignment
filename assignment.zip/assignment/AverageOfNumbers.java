package assignment;

public class AverageOfNumbers {

	public static void main(String[] args) {

		int a= 10;
		float f = 90.78f;
		int b = 111;
		int c = 8989;
		int d = 7876;
		float sum;
		float avg;
		
		sum = a+f+b+c+d;
		avg = sum/5;
		
		System.out.println(avg);

	}

}
