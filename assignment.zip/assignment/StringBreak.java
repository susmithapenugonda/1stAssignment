package assignment;

public class StringBreak {

	public static void main(String[] args) {
		
		String []arr = {"Java","JavaScript","Selenium","Python","Mukesh"};
		
		for(int i=0;i<arr.length;i++) {
			
			if(arr[i]=="Selenium") {
				break;
			}
			
		}

	}

}
