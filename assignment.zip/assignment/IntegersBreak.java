package assignment;

public class IntegersBreak {

	public static void main(String[] args) {
		
		int []arr = {12,34,66,85,900};
		//System.out.println(arr.length);
		for(int i=0;i<arr.length;i++)
		
		{
			if(arr[i]==85)
			{
			//System.out.println(arr[i]);
			break;
			}
		}
	}

}
